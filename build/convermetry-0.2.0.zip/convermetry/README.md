# Convermetry

Visitor analytics, campaign attribution, and **server-confirmed form conversion tracking** with reliable webhook delivery — one WordPress plugin that answers the full funnel question:

```text
Where did this visitor come from?
        ↓
What pages did they visit?
        ↓
What did they interact with?
        ↓
Which form did they submit?
        ↓
Was the submission actually accepted by WordPress?
        ↓
What data did they submit?
        ↓
Which marketing campaign produced the lead?
        ↓
Was the lead successfully delivered to external systems?
```

Convermetry works standalone — full analytics dashboard, form integrations, and webhook delivery inside one WordPress install — and is architected so a future Convermetry SaaS can receive `analytics_report` and `form_submission` messages from many installations, keyed by a shared, versioned payload schema.

- **Version:** 0.1.0
- **Requires WordPress:** 6.3+
- **Requires PHP:** 8.1+
- **License:** GPL-2.0-or-later
- **Text domain / slug:** `convermetry` · **REST namespace:** `convermetry/v1` · **PHP namespace:** `Convermetry\`

---

## Contents

1. [Requirements & installation](#requirements--installation)
2. [Admin pages](#admin-pages)
3. [Analytics tracking](#analytics-tracking)
4. [Campaign & channel attribution](#campaign--channel-attribution)
5. [Session → submission → conversion correlation](#session--submission--conversion-correlation)
6. [Supported form providers](#supported-form-providers)
7. [Custom form integration API](#custom-form-integration-api)
8. [Webhooks](#webhooks)
9. [The three identifiers](#the-three-identifiers-submission_id--conversion_id--delivery_id)
10. [Payload schemas](#payload-schemas)
11. [HMAC signatures](#hmac-signatures)
12. [Retries & idempotency](#retries--idempotency)
13. [Activity Log](#activity-log)
14. [REST APIs](#rest-apis)
15. [Developer hooks](#developer-hooks)
16. [Privacy](#privacy)
17. [Database tables](#database-tables)
18. [Uninstall behavior](#uninstall-behavior)
19. [Feature migration matrix](#feature-migration-matrix)
20. [Folder structure](#folder-structure)
21. [Development & tests](#development--tests)

---

## Requirements & installation

| Requirement | Minimum |
|---|---|
| PHP | 8.1 |
| WordPress | 6.3 |
| Form plugins | Optional — feature-detected (see [Supported form providers](#supported-form-providers)) |

1. Copy the `convermetry` folder into `wp-content/plugins/`.
2. Activate **Convermetry** on the Plugins screen. Activation creates the four custom tables and schedules the cleanup and webhook cron events.
3. Visit **Convermetry** in the admin menu for analytics; configure endpoints under **Convermetry → Webhooks**, form behavior under **Convermetry → Forms**, and tracking/identity under **Convermetry → Settings**.

Activation never fatals when no third-party form plugin is installed — every provider integration is feature-detected at runtime.

## Admin pages

```text
Convermetry
    Analytics      — the reporting dashboard (top-level default)
    Forms          — provider status, discovered forms, per-form configuration
    Webhooks       — endpoints, delivery types, signing, schedule, request customization
    Activity Log   — every delivery attempt with exact payload and response
    Settings       — website/client identity, tracking toggles, privacy, retention
    About          — this documentation inside wp-admin
```

### Analytics

For a selectable 7/30/90-day period (UTC calendar days, clamped to the retention window with an explanatory notice when clamped): summary cards (Page Views, Clicks, Form Submit Attempts, Confirmed Conversions, **Server-Confirmed Submissions**, Hovers, Scroll Milestones, Other Events), an accessible daily page-view chart (single-Tab-stop keyboard navigation, touch/mouse tooltips, visible axes, data-table fallback, horizontal scroll for dense periods), and collapsible sections:

| Section | Reports |
|---|---|
| Overview | Summary cards + daily page-view chart |
| Content | Top Pages, Top Landing Pages |
| Engagement | Top Clicked Elements, Top Form Submit Attempts, Most Hovered Elements |
| Acquisition | Top Referrers, Channels, Campaigns, Campaign Terms & Content |
| Devices | Mobile vs desktop share |
| Conversions | Recent Conversions — each with attribution, provider/form identity, and conversion id |
| Recent Activity | The latest 15 raw events in the site timezone |

A **Print / Save as PDF** button produces a print-optimized report (sections and chart values expanded automatically, landscape campaign tables, link URLs printed). Empty states and per-section database-error notices are explicit — a failed query is never rendered as a silent zero.

The three form metrics are deliberately distinct:

- **Form Submit Attempts** — frontend `submit` events; success unconfirmed.
- **Confirmed Conversions** — unique conversions deduplicated by `conversion_id` across both detection paths.
- **Server-Confirmed Submissions** — submissions a form plugin's own server-side success hook confirmed. When a provider integration is available, this server-side signal is authoritative.

### Forms

Shows each supported provider as **Active** or **Unavailable**, automatically discovers every active provider's forms (cached for five minutes), and offers filtering by provider, name/id text, and included/excluded state. Per form:

| Setting | Meaning |
|---|---|
| Native Form ID | The provider's own identity (read-only) |
| Custom/External Form ID | Sent as `form_id` in payloads; native id is the fallback |
| Enabled / Excluded | Detected forms are **included by default** — new forms need no setup. Exclusion stops processing; configuration is **preserved** while excluded |
| Include page URL query parameters | Per-form override of the global setting |
| URL Query Parameters | Per-form parameters (highest precedence) |
| Request Headers | Per-form headers |

### Webhooks

Endpoints, delivery types, signing, schedule, backfill, failure mode, global headers/query parameters, per-endpoint tests, pending retries, and the pending form-delivery queue — see [Webhooks](#webhooks) below.

### Activity Log / Settings / About

See [Activity Log](#activity-log); Settings holds the website/client identity (`website_info`), tracking toggles, privacy signals, hover dwell, retention, and the Activity Log lead-data privacy switch.

## Analytics tracking

A single dependency-free script (`assets/js/tracker.js`) is enqueued deferred on frontend pages (never for logged-in users when exclusion is on — the default). It batches events and delivers them to `POST /wp-json/convermetry/v1/track`:

```json
{"batch_id": "b3f2a9c1b8e0d", "events": [{"type": "pageview", "page_url": "...", ...}]}
```

**Delivery reliability** — batches flush every 5 seconds, at 20 events, and on page exit via `navigator.sendBeacon`. Every batch is persisted to a bounded `sessionStorage` store *before* it is sent (in-memory fallback when unavailable) and removed only on server acknowledgment (2xx, or a 4xx other than 429). Failed sends back off exponentially with jitter; a 429 pauses the whole tab and honors `Retry-After`. Fetch-delivered batches are **at-least-once** and replays are **idempotent**: rows are stored under a unique `(batch_id, event ordinal)` key, so a replayed batch never inflates counts. Fresh page-exit beacon hand-offs are best-effort; a batch that already survived a failed send stays persisted through a beacon hand-off.

**Endpoint defenses** — whitelisted, currently-enabled event types only; tracked page URLs must be `http(s)` on this site's host and are canonicalized to scheme+host+path; foreign `Origin`/`Referer` rejected; bots and empty user agents ignored; DNT/GPC enforced server-side when enabled; request bodies and batch sizes capped; scalar-only field values, sanitized and truncated; rate limits charged **per event** — 300/IP/minute plus 3,000/minute site-wide (`convermetry_rate_limits` filter) — via atomic object-cache counters, falling back (and failing **closed**) to an atomic single-statement database counter. The per-IP check runs first so a flooding IP never consumes the site-wide budget. A dashboard warning appears for 24 hours after the site-wide cap is hit. IPs are used only as hashed, short-lived rate-limit keys and are never stored.

**Tracked events** (each individually toggleable): `pageview`, `click`, `form_submit` (attempts), `form_success` (confirmed conversions), `hover` (configurable dwell, opt-in via `data-cvm-hover`), `scroll_depth` (50/100%). Custom server-side events via `cvm_track_event()`.

**Sessions** are cookie-free: the id lives in `localStorage` and rotates after 30 minutes of inactivity.

## Campaign & channel attribution

All six UTM parameters (`utm_source`, `utm_medium`, `utm_campaign`, `utm_id`, `utm_term`, `utm_content`) are captured from tagged landing URLs. Ad-click identifiers (`gclid`, `gbraid`, `wbraid`, `fbclid`, `msclkid`, `ttclid`, `twclid`, `li_fat_id`) are recognized — only the parameter **name** is stored (`click_id_type`), never the value — and imply source/medium when no UTM tags are present (`gclid` → `google`/`cpc`).

Attribution is **last-touch within the session**: the most recent tagged landing attributes the visit from that point on, and the snapshot rides on **every** event in the session. Untagged acquisition persists too — the session's entrance referrer travels as `session_referrer` (with an explicit `session_direct` marker for verified direct entrances), so organic/social/referral visits keep their channel across internal navigation. The session's landing page is persisted alongside and carried into each form submission's `analytics_context.landing_page`.

**Channels** — every attributed event is classified at ingestion into: Paid Search, Paid Social, Organic Search, Organic Social, Email, Display, Affiliate, SMS, Referral, Direct, Other. Source aliases are normalized (`fb`/`facebook.com` → `facebook`; `convermetry_source_aliases` filter), referrer hosts match search/social networks only in the registrable-domain position, and the rules are overridable per event (`convermetry_channel` filter). There is exactly **one** attribution engine (`Convermetry\Tracking\Channels`): the dashboard, the analytics payloads, and every form submission's `analytics_context.channel` classify through the same code.

## Session → submission → conversion correlation

The critical link between analytics and leads is **token-based — never timestamps**:

1. On page load (and refreshed at submit time, in the capture phase, *before* any AJAX handler serializes the form) the tracker injects three hidden internal fields into every form:
   - `cvm_conversion_id` — a fresh conversion token per submission attempt,
   - `cvm_session_id` — the current analytics session id,
   - `cvm_context` — a compact JSON snapshot of the session's attribution, entrance referrer/direct marker, landing page, and page URL.
2. The form plugin processes the submission normally. When its **server-side success hook** fires, Convermetry's provider adapter extracts and strictly validates those fields from the request (all transport shapes are handled, including Fluent Forms' serialized `data` blob), and **strips every `cvm_*` field** from the submission data.
3. The confirmed conversion is recorded as a `form_success` analytics event under **that same conversion token**, together with a durable row in the form-submissions table (session id, attribution context, sanitized lead data).
4. The tracker's own frontend success listeners (Elementor `submit_success`, CF7 `wpcf7mailsent`, WPForms `wpformsAjaxSubmitSuccess`, Gravity Forms `gform_confirmation_loaded`) reuse the **same token** for their `form_success` event — so whichever paths fire, every report deduplicates them into **one** conversion by `conversion_id`.

AJAX forms are fully supported (the capture-phase refresh runs before provider serialization). When the fields are absent (tracker disabled, privacy signals honored, JavaScript blocked, server-to-server submissions), the conversion id is generated server-side and the submission still records and delivers — just with an empty `analytics_context`. No cookies are used at any point.

Duplicate protection at every layer: a double-fired provider callback hits the `UNIQUE conversion_id` index and records nothing twice; queue rows are unique per `(submission_id, endpoint)`; reports count `DISTINCT conversion_id`; receivers deduplicate by `delivery_id`.

## Supported form providers

Providers are feature-detected — nothing loads or breaks when a plugin is absent — and discovered automatically:

| Provider | Availability check | Server-confirmed hook | Native identity |
|---|---|---|---|
| Elementor Pro | `ELEMENTOR_PRO_VERSION` / `\ElementorPro\Plugin` | `elementor_pro/forms/new_record` | Form **name** (settings key; widget id travels as `native_form_id`) |
| Gravity Forms | `GFAPI` | `gform_after_submission` | Form id |
| WPForms | `wpforms()` | `wpforms_process_complete` | Form id |
| Contact Form 7 | `WPCF7_ContactForm` | `wpcf7_mail_sent` | Form post id |
| Fluent Forms | `FLUENTFORM` / `wpFluentForm()` | `fluentform/submission_inserted` (+ legacy alias, double-fire-guarded) | Form id |

Elementor discovery walks `_elementor_data` post meta directly (public queries miss private post types such as `elementor_library`). Gravity Forms uses `GFAPI::get_forms()`; WPForms lists the `wpforms` post type; CF7 uses `WPCF7_ContactForm::find()`.

**Delivery behavior for supported forms** (the default, `background` failure mode):

1. The form plugin processes/stores/sends the submission normally.
2. Convermetry captures the server-side success, records the submission + conversion, and queues one delivery per form endpoint — a handful of INSERTs, no payload building, no HTTP.
3. Control returns immediately; the visitor is never delayed.
4. A background worker (kicked within seconds via a spawned cron) builds, enriches, freezes, and sends the payloads, retrying on failure.

An external webhook outage can never make a valid form submission appear to fail. The optional **Show error to visitor** mode (Webhooks page) runs delivery synchronously for Elementor Pro forms and surfaces failures on the form via Elementor's AJAX handler.

## Custom form integration API

Fire-and-forget with background delivery and automatic retries:

```php
do_action('convermetry_form_submission',
    ['form_name' => 'Booking Widget', 'form_id' => 'booking-1'],
    ['name' => $name, 'email' => $email],
    ['url_query' => ['channel' => 'widget'], 'headers' => ['X-Source' => 'booking']] // optional
);
```

Result-aware and synchronous — the caller receives the real outcome and handles failures itself (no automatic retries):

```php
$result = convermetry_submit_form(
    ['form_name' => 'Booking Widget', 'form_id' => 'booking-1'],
    $fields,
    $url_query,       // optional, this call only
    $request_headers  // optional, this call only
);

if (!$result->ok) {
    // $result->msg              — user-facing description
    // $result->status           — last HTTP status (0 for early exits/transport errors)
    // $result->failedDeliveries — exact requests that failed, for custom retry logic
}
// $result->submissionId / $result->conversionId — the recorded identifiers
```

Both paths run the full pipeline — per-form exclusion and overrides (keyed `custom:<form_name>`), correlation-field extraction from the current request, conversion recording, and dedup. Third-party **provider adapters** register via:

```php
add_filter('convermetry_form_providers', function (array $providers) {
    $providers[] = new My_Form_Provider(); // implements Convermetry\Forms\FormProviderInterface
    return $providers;
});
```

Custom **frontend** conversions (goals no server hook can see):

```js
document.dispatchEvent(new CustomEvent('convermetry:conversion', {
    detail: { name: 'appointment_booked' } // optional: conversion_id to correlate with a server record
}));
```

Custom **server-side** analytics events: `cvm_track_event('purchase', ['page_url' => ..., 'event_value' => '99.00']);`

## Webhooks

Configure any number of endpoints under **Convermetry → Webhooks**. Each endpoint has:

| Field | Purpose |
|---|---|
| Webhook URL | HTTPS required (`convermetry_allow_insecure_webhooks` filter allows HTTP for development) |
| Label | Optional; badges Activity Log entries and identifies endpoints in the REST API |
| Signing Secret | Optional per-endpoint HMAC key; overrides the shared secret for this endpoint only |
| **Delivery Types** | **Analytics Reports** and/or **Form Submissions** checkboxes |

So one install can feed, for example:

```text
Convermetry SaaS            Analytics ✓   Form Submissions ✓
HubSpot Middleware          Analytics ✗   Form Submissions ✓
Reporting Data Warehouse    Analytics ✓   Form Submissions ✗
```

**Analytics reports** are sent hourly, twice daily, daily, or weekly. Delivery windows are tracked **per endpoint** (each payload covers the time since that endpoint's last successful delivery); gaps longer than one interval — downtime, a paused status toggle, or an enabled **history backfill** for new endpoints — are delivered as consecutive, non-overlapping, interval-sized windows (up to 10 per run). Conversion delivery is **lossless**: a window holding more than 100 individual conversions is split into consecutive deliveries rather than truncated. Each site's schedule is anchored at a stable random offset within the interval so fleets sharing one endpoint never stampede it, and dispatch runs under a site-wide mutex (MySQL named lock, with a token/lease option-row fallback) so overlapping cron executions can never build overlapping windows. Each `top_*` list holds up to 200 rows (`convermetry_webhook_report_limit`).

**Form submissions** are delivered immediately in the background from a database-backed queue — one row per submission × endpoint (see [Retries & idempotency](#retries--idempotency)).

**Request customization** (applies to the URL and headers of outbound requests):

- **Global headers** (e.g. `Authorization`) on every request — sent intact, redacted in the Activity Log.
- **Global URL query parameters** on every request.
- **Page URL parameters** — optionally pass the submitting page's query string through to form-submission webhook URLs (global default plus per-form override).
- **Per-form query parameters and headers** (Forms page), **runtime** parameters/headers (custom API calls).

Merge precedence for query parameters (later overrides earlier for shared keys):

```text
Global URL parameters → Page URL parameters → Per-form URL parameters → Runtime parameters
```

Headers: `Content-Type` → global → per-form → runtime, with `User-Agent`, `Idempotency-Key`, and `X-Convermetry-Signature` added at send time.

**Per-endpoint tests** — every endpoint block has **Send analytics test** and **Send form test** buttons. Test payloads carry `"test": true` and clearly marked sample data, never touch delivery markers or real submissions, are never retried, and appear in the Activity Log with kind `test`.

All requests go through one transport: `wp_safe_remote_post()` (URL re-validated at request time — SSRF protection even if DNS changed after saving), redirects disabled, response downloads capped at 64 KB at the transport layer, 15-second timeout.

## The three identifiers: `submission_id` / `conversion_id` / `delivery_id`

| Identifier | Identifies | Scope | Deduplicate by it when… |
|---|---|---|---|
| `submission_id` | The form submission itself | **Global** — identical in every delivery of that submission, to every endpoint | You aggregate the same lead arriving via multiple endpoints |
| `conversion_id` | The analytics conversion joined to the submission (and its session) | Shared between the frontend `form_success` event and the server-confirmed record | You count conversions (all Convermetry reports do exactly this) |
| `delivery_id` | One outbound webhook delivery | **Endpoint-specific**; stable across every retry of that delivery; echoed as `Idempotency-Key` | You receive webhooks — dedup by `delivery_id` is sufficient to never double-process |

Supporting identifiers: `batch_id` + event ordinal make tracker ingestion idempotent; `session_id` groups one visit.

## Payload schemas

Every outbound message shares one versioned envelope:

```json
{
    "schema_version": "1.0",
    "source": "convermetry",
    "plugin_version": "0.1.0",
    "message_type": "analytics_report | form_submission",
    "website_info": { },
    "generated_at": "2026-08-22T14:00:00+00:00",
    "delivery_id": "…"
}
```

`website_info` is produced by one builder for both message types. Every key is always present (empty string when unconfigured) so consumers get a predictable schema; `domain` derives automatically from the home URL with `www.` stripped:

```json
"website_info": {
    "name": "Example Financial",
    "url": "https://www.example.com",
    "domain": "example.com",
    "id": "site-123",
    "client": { "first_name": "Jane", "last_name": "Smith", "id": "client-456" }
}
```

### Analytics report payload

```json
{
    "schema_version": "1.0",
    "source": "convermetry",
    "plugin_version": "0.1.0",
    "message_type": "analytics_report",
    "website_info": {
        "name": "Example Financial", "url": "https://example.com", "domain": "example.com",
        "id": "site-123",
        "client": { "first_name": "Jane", "last_name": "Smith", "id": "client-456" }
    },
    "generated_at": "2026-08-22T14:00:00+00:00",
    "delivery_id": "0f52c1d6a4b98e73d21f06c58a9b3e47",
    "period": {
        "start": "2026-08-21T14:00:00+00:00",
        "end": "2026-08-22T14:00:00+00:00"
    },
    "analytics": {
        "totals": { "pageview": 1240, "click": 512, "form_submit": 38, "form_success": 24, "hover": 940, "scroll_depth": 2210 },
        "daily_pageviews": [ { "date": "2026-08-21", "count": 610 }, { "date": "2026-08-22", "count": 630 } ],
        "top_pages": [ { "page_url": "https://example.com/", "page_title": "Home", "views": 400, "sessions": 310 } ],
        "top_landing_pages": [ { "page_url": "https://example.com/spring-sale/", "page_title": "Spring Sale", "sessions": 180 } ],
        "top_clicks": [ { "element_label": "Get a Quote", "element_tag": "a", "target_url": "https://example.com/quote", "clicks": 88 } ],
        "top_forms": [ { "element_label": "contact-form", "page_url": "https://example.com/contact", "submissions": 21 } ],
        "top_hovers": [ { "element_label": "Pricing", "element_tag": "a", "hovers": 130 } ],
        "top_referrers": [ { "referrer": "https://www.google.com/", "visits": 210 } ],
        "top_campaigns": [
            {
                "utm_source": "newsletter", "utm_medium": "email", "utm_campaign": "spring-sale",
                "utm_id": "cmp-2210", "channel": "Email",
                "views": 96, "sessions": 74,
                "conversions": 7, "converting_sessions": 6, "conversion_rate": 8.11
            }
        ],
        "top_campaign_content": [
            {
                "utm_source": "google", "utm_medium": "cpc", "utm_campaign": "summer-sale",
                "utm_id": "cmp-3301", "utm_term": "emergency plumber", "utm_content": "ad-variant-b",
                "views": 42, "sessions": 31, "conversions": 3
            }
        ],
        "channels": [
            { "channel": "Paid Search", "views": 320, "sessions": 240, "conversions": 12, "converting_sessions": 11, "conversion_rate": 4.58 }
        ],
        "conversions": {
            "total": 24,
            "server_confirmed": 19,
            "recent": [
                {
                    "conversion_id": "c1f52c1d6a4b98e73",
                    "form": "Contact Form",
                    "page_url": "https://example.com/contact",
                    "referrer": "https://example.com/services",
                    "device": "desktop",
                    "session_id": "9f2c…",
                    "occurred_at": "2026-08-22 09:14:02",
                    "server_confirmed": true,
                    "submission_id": "s5f2a9c1b8e0d21f06c5",
                    "provider": "elementor",
                    "form_id": "contact-form-01",
                    "native_form_id": "7ac3d1f",
                    "attribution": {
                        "channel": "Paid Search",
                        "utm_source": "google", "utm_medium": "cpc", "utm_campaign": "summer-sale",
                        "utm_id": "", "utm_term": "", "utm_content": "",
                        "click_id_type": "gclid"
                    }
                }
            ]
        },
        "devices": { "desktop": 820, "mobile": 420 }
    }
}
```

`analytics.conversions.recent` lists **every** conversion in the delivery window (lossless — oversized windows split), each with the attribution snapshot taken when it occurred, plus the provider/form/submission identity when server-confirmed. The dashboard and this payload use the **same query layer**, so their numbers cannot disagree.

### Form submission payload

```json
{
    "schema_version": "1.0",
    "source": "convermetry",
    "plugin_version": "0.1.0",
    "message_type": "form_submission",
    "website_info": {
        "name": "Example Financial", "url": "https://example.com", "domain": "example.com",
        "id": "site-123",
        "client": { "first_name": "Jane", "last_name": "Smith", "id": "client-456" },
        "page": {
            "url": "https://example.com/contact",
            "query": { "utm_source": "google", "utm_medium": "cpc" }
        }
    },
    "generated_at": "2026-08-22T14:32:00+00:00",
    "delivery_id": "endpoint-specific-idempotent-delivery-id",
    "form_submission": {
        "submission_id": "s5f2a9c1b8e0d21f06c5",
        "conversion_id": "c1f52c1d6a4b98e73",
        "provider": "elementor",
        "form_name": "Contact Form",
        "form_id": "contact-form-01",
        "native_form_id": "7ac3d1f",
        "submission_data": {
            "name": "John Doe",
            "email": "john@example.com",
            "phone": "555-555-5555",
            "message": "I would like more information."
        }
    },
    "analytics_context": {
        "session_id": "9f2c4be1a6d8c3f0…",
        "channel": "Paid Search",
        "attribution": {
            "utm_source": "google", "utm_medium": "cpc", "utm_campaign": "retirement-planning",
            "utm_id": "", "utm_term": "financial advisor", "utm_content": "ad-b",
            "click_id_type": "gclid"
        },
        "entrance_referrer": "https://www.google.com/",
        "landing_page": { "url": "https://example.com/retirement-planning/" },
        "device": "desktop",
        "pageview_count": 4,
        "session_started_at": "2026-08-22T14:20:11+00:00",
        "recent_pages": ["https://example.com/contact", "https://example.com/retirement-planning/"]
    }
}
```

`generated_at` is the submission's creation time — identical across endpoints and retries. The session-summary fields (`pageview_count`, `session_started_at`, `recent_pages`) are enriched in the background worker via two small indexed queries, never during the visitor's request, and frozen with the payload. Submissions without correlation data carry the same `analytics_context` keys with empty values. There is **no** `client_location_data` and no external geolocation call — a `geo` block can be added later as an ingestion-side enrichment without schema changes.

## HMAC signatures

When a signing secret is configured (shared, or per-endpoint — the endpoint's own secret wins, so one receiver never learns the key that signs payloads for others), every request carries:

```text
X-Convermetry-Signature: sha256=<hex>
```

— the HMAC-SHA256 of the **raw JSON body bytes**, keyed with the secret. Verify by recomputing over the exact received bytes and comparing with a constant-time function:

```php
$expected = 'sha256=' . hash_hmac('sha256', $rawBody, $secret);
if (!hash_equals($expected, $_SERVER['HTTP_X_CONVERMETRY_SIGNATURE'] ?? '')) { http_response_code(401); exit; }
```

Signatures are computed at send time over the frozen bytes, so retries re-sign the identical body; rotating a secret mid-retry simply signs the same bytes with the new key. See [Retries & idempotency](#retries--idempotency) for why the signature header is deliberately not frozen.

## Retries & idempotency

Both message types share the retry schedule (filterable via `convermetry_retry_schedule`):

```text
Initial delivery → 5 minutes → 30 minutes → 2 hours → 6 hours → 16 hours   (~24.6 h total)
```

**Frozen requests.** On the first delivery attempt the final URL (all query-parameter layers merged), the configured headers, and the serialized JSON body are frozen. Every retry replays those exact bytes under the same `delivery_id`/`Idempotency-Key` — retention cleanup, settings changes, or plugin updates between attempts can never mutate a frozen retry.

**Three headers are regenerated per attempt rather than frozen**, a deliberate deviation from strict byte-for-byte header freezing:

| Header | Why it is not frozen |
|---|---|
| `Idempotency-Key` | Equal to the frozen `delivery_id`, so it is stable in practice — regenerating it cannot change its value. |
| `User-Agent` | Reflects the running plugin version. |
| `X-Convermetry-Signature` | Recomputed over the frozen bytes with the endpoint's **current** secret. |

Freezing the signature would make secret rotation destructive: a receiver validates against its current secret, so every remaining attempt in an in-flight chain would fail authentication until the chain was abandoned. Re-signing identical bytes means rotation costs nothing and requires no receiver-side grace window. The body a receiver verifies is byte-identical across attempts either way.

The signing secret is resolved by the endpoint's **permanent id**, captured when the delivery was frozen — not by its URL. Editing an endpoint's URL mid-chain therefore keeps signing with that endpoint's own secret. If the endpoint has been deleted, no signature header is sent at all, rather than one made with the shared secret that a receiver could not distinguish from a forgery. A payload that fails to JSON-encode (e.g. a filter introduced an unencodable value) is treated as a *failed attempt* entering the normal chain; an empty body is never sent, and the payload is never rebuilt without the filter.

**Analytics reports** — per-endpoint retry chains via single-event crons. An exhausted chain (or one whose cron could not be scheduled — detected as *orphaned*) keeps its frozen delivery; the next scheduled dispatch re-sends it under the original `delivery_id` first, and only after acknowledgment does the endpoint's marker advance — exactly to the frozen window's end — so consecutive deliveries never overlap. Every retry-state mutation happens under the dispatch mutex. Deactivating the plugin *suspends* chains (frozen deliveries resume after reactivation under their original ids); frozen deliveries older than the retention window expire, and each pending retry has a **Discard** action on the Webhooks page.

**Form submissions** — one queue row per submission × endpoint in `cvm_delivery_queue`. Endpoints that acknowledged are deleted from the queue and **never re-sent** when a sibling endpoint fails. Rows are claimed atomically (a token-stamped conditional `UPDATE`), so overlapping workers can't double-send; rows stranded in `sending` by a dead worker are reclaimed after 10 minutes. The worker cron is re-armed by activation, the daily cleanup, and every analytics dispatch run, so queued leads survive lost cron events and deactivate/reactivate cycles. After the final failed attempt the delivery is abandoned — every attempt remains in the Activity Log.

**Delivery is at-least-once.** Any duplicate a receiver can ever see carries a `delivery_id` it has already processed — deduplicating by `delivery_id` is sufficient to never double-count.

## Activity Log

**Convermetry → Activity Log** records every delivery attempt — analytics report or form submission; scheduled, immediate, retry, or test — as normalized columns (`message_type`, `kind`, `attempt`; never parsed from display labels), with: timestamp, endpoint URL + label, delivery/submission/conversion ids, form provider and name, HTTP status, final request URL, request headers (credential values redacted), the **exact JSON payload sent**, the response body, and transport errors.

Two paginated accordions (Successful / Failed) offer year/month, message-type, endpoint, provider, and form filters, debounced payload search, a per-page selector (5–100), and per-entry delete. The toolbar provides **Clear All Logs** and **CSV/JSON export** — both stream in keyset-paginated chunks, so even huge logs export in bounded memory. Entries share the analytics retention window.

**Log security:** response bodies are size-capped at download (64 KB via `limit_response_size`) and at storage; values of sensitive-looking keys (`password`, `passwd`, `secret`, `token`, `authorization`, `api_key`, `apikey`, `access_token`, `refresh_token`, `client_secret`, …) in JSON bodies are replaced with `[REDACTED]` (BOM/whitespace-prefixed JSON included); configured credential headers are stored redacted (sent intact); signing secrets never appear in logs. The `convermetry_delivery_log_row` filter allows site-specific redaction of e.g. PII fields, or skipping a row entirely; a Settings toggle can exclude form `submission_data` from stored payloads while keeping delivery metadata.

## REST APIs

### `POST /wp-json/convermetry/v1/track` (public)

The tracker's ingestion endpoint — see [Analytics tracking](#analytics-tracking) for its validation, dedup, rate-limiting, and privacy behavior. Answers `202` with `{"stored": n}`, `400`/`403`/`413`/`429` (`Retry-After`) on rejection, and `503` when storage failed (the tracker keeps the batch and retries).

### `GET /wp-json/convermetry/v1/deliveries` (API-key)

Read-only Activity Log API, off by default; enable it (and manage its key) on the Activity Log page.

```text
GET /wp-json/convermetry/v1/deliveries?page=1&per_page=25&status=error&message_type=form_submission
Authorization: <api-key>
```

| Parameter | Values |
|---|---|
| `page` / `per_page` | Pagination (`per_page` max 100) |
| `status` | `success` \| `error` |
| `message_type` | `analytics_report` \| `form_submission` |
| `endpoint` | An endpoint **label**, or the `endpoint_key` (md5 of the URL) echoed in responses |
| `provider` | Form provider key |
| `form_id` | Exact form name |
| `after` | `YYYY-MM` or `YYYY-MM-DD` (calendar-month filter) |

Pagination metadata returns in `X-WP-Total`, `X-WP-TotalPages`, and `X-CVM-Page` headers. Only a SHA-256 hash of the key is stored — the raw key is shown **once** at generation; regenerating invalidates the old key immediately. Wrong keys get `401` (throttled per IP after repeated failures → `429`); a disabled API answers `403`. In responses, `endpoint_url` is **redacted to scheme + host** — webhook URLs frequently embed bearer tokens, and this read-only key must never hand out downstream write credentials; identify endpoints by `endpoint_label`/`endpoint_key` (full URLs stay visible to admins in wp-admin). Intended for **server-to-server** use — CORS permits browser calls for flexibility, but never embed the key in public frontend JavaScript.

## Developer hooks

| Hook | Type | Purpose |
|---|---|---|
| `convermetry_tracked_event` | filter | Inspect/modify an event row before storage; return `false` to drop. `(array $row, string $type)` |
| `convermetry_webhook_payload` | filter | Modify any outbound payload before it is frozen/encoded. `(array $payload, string $messageType, array $meta)` — `$meta` is `['start','end']` for reports, `['submission_id']` for submissions |
| `convermetry_webhook_report_limit` | filter | Max rows per `top_*` list in analytics payloads (default 200) |
| `convermetry_allowed_hosts` | filter | Hostnames accepted in tracked URLs / Origin checks, treated as internal in referrer reports |
| `convermetry_client_ip` | filter | Map the client IP used for rate limiting (reverse proxies) |
| `convermetry_rate_limits` | filter | `['per_ip' => 300, 'site_wide' => 3000]` events/minute |
| `convermetry_source_aliases` | filter | Extend/override the utm_source alias map |
| `convermetry_channel` | filter | Override the marketing channel assigned at ingestion. `(string $channel, array $row, string $type)` |
| `convermetry_delivery_log_row` | filter | Redact/modify an Activity Log row before storage; return `false` to skip logging |
| `convermetry_allow_insecure_webhooks` | filter | Return `true` to allow `http://` endpoints (development only) |
| `convermetry_form_providers` | filter | Register custom `FormProviderInterface` adapters |
| `convermetry_retry_schedule` | filter | The retry backoff delays in seconds (both message types) |
| `convermetry_form_submission` | action | Submit a custom form (fire-and-forget, background delivery) |
| `convermetry_submission_recorded` | action | Fires after a submission is recorded, before delivery. `($submissionId, $conversionId, $context)` |

Helper functions: `convermetry_submit_form()` (result-aware submission) and `cvm_track_event()` (custom server-side analytics event).

## Privacy

- **No cookies.** Session ids live in `localStorage` and rotate after 30 minutes of inactivity.
- Tracked URLs are canonicalized to scheme + host + path — **no query strings are ever stored**. Referrers and click/form destinations are likewise stripped (whole `mailto:`/`tel:` destinations are kept — the address *is* the destination; strip via `convermetry_tracked_event` if unacceptable).
- Campaign values are stored after sanitization, except values containing `@` (dropped as likely emails) — never put personal data in UTM parameters. Ad-click identifiers store only the parameter **name**; the value never leaves the browser.
- **No IP addresses or user agents are stored** — the IP is only a hashed, short-lived rate-limit key (`convermetry_client_ip` for proxies). **No external geolocation service is ever contacted** — the legacy synchronous ipapi.co lookup was deliberately removed; a form submission never waits on any third party.
- Optional **Do Not Track / Global Privacy Control** handling (off by default), enforced in the tracker, at the REST endpoint, and in the server-side conversion recorder. DNT/GPC is an opt-out signal, not a consent mechanism — gate the tracker with your consent tool if your jurisdiction requires consent.
- Logged-in users are excluded from tracking by default.
- Form `submission_data` is first-party lead data the visitor actively submitted; it is stored for delivery/retry and ages out with retention. The Activity Log's copy can be disabled in Settings, and `convermetry_delivery_log_row` supports field-level redaction.
- Everything is deleted after the configurable retention window (7–365 days, default 90) by bounded, chunked cleanup jobs.

## Database tables

| Table | Purpose |
|---|---|
| `{$prefix}cvm_events` | One row per visitor interaction (analytics engine). Unique `(batch_id, batch_seq)` makes tracker replays idempotent; indexed by type/date, type/session/date, date, and page URL. `form_success` rows carry the `conversion_id` in `event_value`. |
| `{$prefix}cvm_form_submissions` | One row per server-confirmed submission: `submission_id` (unique), `conversion_id` (unique — the dedup point), session id, provider/form identity, page URL + query, sanitized `submission_data`, frozen `analytics_context`, runtime overrides. |
| `{$prefix}cvm_delivery_queue` | The background form-delivery queue: one row per submission × endpoint with status, attempt, next-attempt time, claim token, and the frozen URL/headers/body. Rows are deleted on acknowledgment or abandonment. |
| `{$prefix}cvm_webhook_deliveries` | The Activity Log: one row per delivery attempt with normalized `message_type`/`kind`/`attempt` columns, identifiers, redacted headers, exact payload, and response. |

All tables are created via `dbDelta()` with versioned schema options; migrations are **verified** (columns and critical indexes checked) before their version is recorded, so a failed/partial migration retries on the next load. Large retry state never lives in autoloaded options — the analytics retry-state and last-sent options are stored with `autoload = no`, and form payloads live in the queue table.

## Uninstall behavior

**Deactivation preserves everything:** tables and data are kept, analytics retry chains are suspended (frozen deliveries resume under their original `delivery_id`s after reactivation), and queued form deliveries wait in the database for the re-armed worker.

**Deleting the plugin** (Plugins screen) runs `uninstall.php`: drops all four tables, deletes every option, transient, rate-limit counter row, and scheduled cron event. On **multisite**, the cleanup runs per site across the whole network. No trace remains.

## Feature migration matrix

Convermetry replaces two predecessor plugins. This maps each predecessor capability onto where it
now lives, and calls out the places where behaviour deliberately changed rather than carried over.

> Verify the left-hand column against your actual installed versions before relying on this for a
> production migration — it reflects the capabilities Convermetry implements, not an audit of the
> legacy codebases.

### SitePulse (analytics) → Convermetry

| Predecessor capability | Now | Notes |
|---|---|---|
| Pageview / click / hover / scroll tracking | **Convermetry → Settings**, per-event toggles | `assets/js/tracker.js`; same event types |
| Campaign & referrer attribution | **Campaign & channel attribution** | One shared engine (`Tracking/Channels`) for dashboard *and* payloads |
| Analytics dashboard & reports | **Convermetry → Analytics** | Shared query layer (`Analytics/Reports`) |
| Data retention / cleanup | **Settings → retention**, daily cron | Bounded chunked deletes; multisite-aware uninstall |
| Logged-in exclusion, DNT/GPC | **Settings → privacy** | DNT/GPC off by default; logged-in exclusion on |
| — | **Scheduled `analytics_report` webhooks** | New: per-endpoint windows, retries, idempotency |

### Forms Webhook Integrator (form delivery) → Convermetry

| Predecessor capability | Now | Notes |
|---|---|---|
| Per-form webhook configuration | **Convermetry → Forms** | Same per-form model; see identity change below |
| Per-form headers & query parameters | **Forms page**, merged by `RequestFactory` | Four-layer precedence: global → page → form → runtime |
| Custom/external form ID | **Forms → Custom/External Form ID** | Frozen into the payload *and* the Activity Log `form_id` column |
| Form exclusions | **Forms → Excluded** | Configuration is preserved while excluded |
| Elementor form settings keyed by **form name** | **Keyed by widget id**, name kept as fallback | **Behaviour change** — see below |
| Synchronous delivery with visible errors | **Settings → failure mode** (`background` \| `show_error`) | `show_error` is Elementor-only; it is the one provider API exposing that channel |
| — | **Durable queue, retries, idempotency** | New: delivery survives outages; at-least-once with `delivery_id` dedup |
| — | **Session → submission correlation** | New: every lead carries its analytics session and campaign |

### Behaviour changes to know about when migrating

| Change | Why | What to do |
|---|---|---|
| Elementor per-form settings move from form **name** to **widget id** | Two widgets sharing a name previously collapsed into one configuration | Nothing required. Existing name-keyed settings keep working; saving a form migrates it. The legacy entry is retained, not deleted, so queued deliveries frozen before the save still resolve correctly |
| `X-Convermetry-Signature` is re-signed per attempt, not frozen | Freezing it would make rotating a secret fail every in-flight retry | Nothing — verify against the raw body as documented |
| Activity Log redacts credential-like fields in **request** payloads | They were previously stored and exported in the clear | A one-time background migration redacts existing rows on the daily cleanup cron |
| Delivery Log API `form_id` filters the real form id | It previously filtered the form *name* | Rows predating the column are backfilled from the stored payload |
| Delivery Log API `after`/`before` are true UTC day bounds | `before` was ignored; `after` matched a whole month | An invalid date now returns `400` instead of being silently dropped |

## Folder structure

```text
convermetry/
├── convermetry.php              # Plugin header, PHP 8.1 guard, bootstrap, activation, helpers
├── uninstall.php                # Complete cleanup on plugin deletion (multisite-aware)
├── README.md
├── composer.json                # Dev-only: PHPUnit + Brain Monkey, platform pinned to PHP 8.1
├── phpunit.xml                  # Unit suite config
├── .distignore                  # Development artifacts excluded from the release ZIP
├── bin/build-zip.sh             # Builds the distributable ZIP (verifies no dev artifacts leak)
├── .github/workflows/ci.yml     # Suite on PHP 8.1/8.2/8.3 + release-ZIP cleanliness gate
├── tests/                       # Unit tests (no WordPress install required)
├── assets/
│   ├── css/admin.css            # Shared admin styles (cards, toggles, logs, forms, builders)
│   ├── css/dashboard.css        # Analytics dashboard + print styles
│   ├── js/admin.js              # Webhooks/Forms pages (repeater, builders, tests, filtering)
│   ├── js/dashboard.js          # Chart navigation/tooltips, panel state, print prep
│   ├── js/activity-log.js       # Activity Log accordions, filters, pagination, API card
│   └── js/tracker.js            # Frontend tracker + form correlation
└── src/
    ├── Autoloader.php           # Minimal PSR-4 autoloader (no Composer)
    ├── Plugin.php               # Composition root
    ├── Admin/                   # AnalyticsPage, FormsPage, WebhooksPage, ActivityLogPage, SettingsPage, AboutPage
    ├── Analytics/               # Reports (shared query layer), ReportQueryException
    ├── Api/                     # TrackingController, DeliveryLogController
    ├── Database/                # DatabaseManager (events), FormSubmissions
    ├── Forms/                   # FormProviderInterface, FormProviderRegistry, FormSettings,
    │   │                        # SubmissionService, SubmissionResult
    │   └── Providers/           # Elementor, GravityForms, WPForms, ContactForm7, FluentForms
    ├── Settings/                # Options (typed settings access)
    ├── Support/                 # Http (the single safe outbound transport)
    ├── Tracking/                # Channels (the one attribution engine), Correlation, ScriptLoader
    └── Webhook/                 # WebsiteInfoBuilder, PayloadBuilder, RequestFactory,
                                 # AnalyticsDispatcher, FormDeliveryQueue, DeliveryLog
```

## Development & tests

The plugin has **no runtime Composer dependencies** — `src/Autoloader.php` is a minimal PSR-4
autoloader, and the shipped ZIP contains no `vendor/`. Composer is used only for test tooling.

Building the distributable ZIP needs nothing beyond a clone:

```bash
bin/build-zip.sh        # writes build/convermetry-<version>.zip
```

It stages only git-tracked files, drops everything listed in `.distignore`, and **fails rather than
producing an archive** if a development artifact reaches the staging directory.

### Running the suite

```bash
composer install        # PHPUnit + Brain Monkey (dev only)
composer test           # unit suite
```

`composer.json` pins `config.platform.php` to `8.1.0`, so the suite resolves the dependency versions
an actual 8.1 host would get rather than whatever the developer's PHP happens to be. Verified green
on PHP 8.2 and 8.5: 51 tests, 93 assertions.

### What the unit suite covers

Redaction (including the `X-API-Key` regression and the `author` false-positive guard), the
four-layer header/query merge precedence, the frozen-retry contract and its documented signature
exception, endpoint-id state migration and the URL-edit regression, Elementor identity fallback, and
date-bound validation.

### What it deliberately does not cover

Brain Monkey stubs WordPress functions; it does not run WordPress. These need a live install and stay
on the manual checklist:

- `dbDelta()` schema migrations against a populated pre-upgrade database
- Real form-plugin hook lifecycles — in particular the **unresolved** Fluent Forms and WPForms spam
  questions recorded in those providers' `registerHooks()` docblocks
- WP-Cron scheduling and retry timing
- REST authentication and rate limiting
- End-to-end delivery against a real receiver
